package com.spring.handas.dto;

public class UserDto {

}
