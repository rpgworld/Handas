package com.spring.handas.dao;

public interface UserDao {
	public String login(String userId);
}
