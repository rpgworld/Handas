package com.spring.handas.dao;

import java.util.ArrayList;

import com.spring.handas.dto.BbsDto;

public interface BbsDao {
	public ArrayList<BbsDto> bbsList();
}
